import{j as a,R as e}from"./chunk-4b1ad6f3.js";const r=()=>a(e.Fragment,null,a("h1",null,"^_^"));export{r as default};
