import{j as a,a as e}from"./chunk-497d7653.js";const r=()=>a(e.Fragment,null,a("h1",null,"^_^"));export{r as default};
