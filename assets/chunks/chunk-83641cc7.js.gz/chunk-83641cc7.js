import{j as a,d as e}from"./chunk-34c2d97f.js";const r=()=>a(e.Fragment,null,a("h1",null,"^_^"));export{r as default};
